package me.coding.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import me.coding.sample.entity.Problem;
import me.coding.sample.repository.ProblemRepo;

@Service
public class ProblemService {
  @Autowired
  private ProblemRepo problemRepo;

  public Problem createProblem(Problem problem) {
    return problemRepo.save(problem);
  }
}
