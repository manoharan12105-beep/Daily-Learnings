package me.coding.sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import me.coding.sample.entity.Problem;
import me.coding.sample.service.ProblemService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api")
public class ProblemController {
  @Autowired
  private ProblemService problemService;

  @PostMapping("/add/problem")
  public Problem postMethodName(@RequestBody Problem problem) {
      return problemService.createProblem(problem);
  }
  
}

// {
//   "title": "GCD of Odd and Even Sums",
//   "level": "Easy",
//   "description": "You are given an integer n. Your task is to compute the GCD (greatest common divisor) of two values:\n\n1. sumOdd: the sum of the first n odd numbers.\n2. sumEven: the sum of the first n even numbers.\n\nReturn the GCD of sumOdd and sumEven.\n\n\nExample 1:\nInput: n = 4\nOutput: 4\nExplanation:\n- Sum of first 4 odd numbers = 1 + 3 + 5 + 7 = 16\n- Sum of first 4 even numbers = 2 + 4 + 6 + 8 = 20\n- GCD(16, 20) = 4\n\nExample 2:\nInput: n = 5\nOutput: 5\nExplanation:\n- Sum of first 5 odd numbers = 1 + 3 + 5 + 7 + 9 = 25\n- Sum of first 5 even numbers = 2 + 4 + 6 + 8 + 10 = 30\n- GCD(25, 30) = 5\n\n\nConstraints:\n1 <= n <= 1000"
// }
