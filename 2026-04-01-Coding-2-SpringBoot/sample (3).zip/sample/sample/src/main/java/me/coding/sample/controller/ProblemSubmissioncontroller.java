package me.coding.sample.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import me.coding.sample.entity.ProblemSubmission;
import me.coding.sample.service.ProblemSubmissionService;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") 
public class ProblemSubmissioncontroller {

  @Autowired
  private ProblemSubmissionService problemSubmissionService;

  @PostMapping("/submit")
  public Map<String, Object> submit(@RequestBody Map<String, Object> req) {
      return problemSubmissionService.submitCode(req);
  }
  
  @PostMapping("/run")
  public Map<String, Object> run(@RequestBody Map<String, Object> req) {
      return problemSubmissionService.runCode(req);
  }
  
}
