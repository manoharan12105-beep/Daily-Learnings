package me.coding.sample.service;

import java.io.*;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import me.coding.sample.entity.*;
import me.coding.sample.repository.*;

@Service
public class ProblemSubmissionService {

    @Autowired
    private ProblemOutputRepo problemOutputRepo;

    @Autowired
    private ProblemRepo problemRepo;

    @Autowired
    private ProblemSubmissionRepo submissionRepo;

    public Map<String, Object> runCode(Map<String, Object> req) {

        String code = (String) req.get("code");
        String input = (String) req.get("input");

        String output = executeCode(code, input);

        Map<String, Object> res = new HashMap<>();
        res.put("output", output);

        return res;
    }

    public Map<String, Object> submitCode(Map<String, Object> req) {

        String code = (String) req.get("code");
        Long problemId = Long.parseLong(req.get("problemId").toString());

        Problem problem = problemRepo.findById(problemId)
                .orElseThrow(() -> new RuntimeException("Problem not found"));

        List<ProblemOutput> testCases =
                problemOutputRepo.findByProblem_ProblemId(problemId);

        int passed = 0;
        long totalRuntime = 0;

        for (ProblemOutput tc : testCases) {

            String input = tc.getInput();
            String expected = tc.getOutput();

            long start = System.nanoTime();

            String actual = executeCode(code, input);

            long end = System.nanoTime();
            long runtime = (end - start) / 1_000_000; // ms

            totalRuntime += runtime;

            if (expected.equals(actual)) {
                passed++;
            }
        }

        String status = (passed == testCases.size()) ? "ACCEPTED" : "FAILED";

        ProblemSubmission ps = new ProblemSubmission();
        ps.setCode(code);
        ps.setProblem(problem);
        ps.setStatus(status);
        ps.setRuntime(totalRuntime + " ms");

        submissionRepo.save(ps);

        Map<String, Object> res = new HashMap<>();
        res.put("status", status);
        res.put("passed", passed);
        res.put("total", testCases.size());
        res.put("runtime", totalRuntime + " ms");

        return res;
    }

    private String executeCode(String userCode, String input) {

        try {

            String fullCode =
                    "public class Main {\n" +
                    "    public static void main(String[] args) {\n" +
                    "        int input = Integer.parseInt(args[0]);\n" +
                    "        System.out.println(new Solution().solve(input));\n" +
                    "    }\n" +
                    "}\n" +
                    "class Solution {\n" +
                    "    public int solve(int input) {\n" +
                    userCode + "\n" +
                    "    }\n" +
                    "}";

            FileWriter writer = new FileWriter("Main.java");
            writer.write(fullCode);
            writer.close();

            Process compile = Runtime.getRuntime().exec("javac Main.java");
            compile.waitFor();

            Process run = Runtime.getRuntime().exec("java Main " + input);

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(run.getInputStream())
            );

            return reader.readLine();

        } catch (Exception e) {
            return "ERROR";
        }
    }
}