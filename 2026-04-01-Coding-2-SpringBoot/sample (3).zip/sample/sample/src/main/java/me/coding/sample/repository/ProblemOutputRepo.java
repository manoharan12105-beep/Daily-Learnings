package me.coding.sample.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import me.coding.sample.entity.ProblemOutput;

public interface ProblemOutputRepo extends JpaRepository <ProblemOutput, Long> {

  List<ProblemOutput> findByProblem_ProblemId(Long problemId);
  
}
