package me.coding.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import me.coding.sample.entity.User;
import me.coding.sample.repository.UserRepo;

@Service
public class UserService {
  @Autowired
  private UserRepo userRepo;

  public User createUser(User user) {
    return userRepo.save(user);
  }
  

  public Boolean validate(User user) {
    if (user == null) {
        return false;
    }

    User dbUser = userRepo.findByUsername(user.getUsername());

    if (dbUser == null) {
        return false;
    }

    return dbUser.getPassword().equals(user.getPassword());
}
}
