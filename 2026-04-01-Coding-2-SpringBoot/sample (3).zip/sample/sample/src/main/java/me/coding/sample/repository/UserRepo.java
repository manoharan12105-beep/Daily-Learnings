package me.coding.sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import me.coding.sample.entity.User;

public interface UserRepo extends JpaRepository<User, Long> {
  User findByUsername(String username);
}
