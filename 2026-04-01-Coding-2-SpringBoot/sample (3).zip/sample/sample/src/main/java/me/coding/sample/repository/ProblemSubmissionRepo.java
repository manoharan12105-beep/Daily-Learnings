package me.coding.sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import me.coding.sample.entity.ProblemSubmission;

public interface ProblemSubmissionRepo extends JpaRepository <ProblemSubmission, Long> {
  
}
