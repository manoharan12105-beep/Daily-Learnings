package me.coding.sample.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import me.coding.sample.entity.Problem;
import me.coding.sample.repository.ProblemRepo;

@Service
public class ProblemService {
  @Autowired
  private ProblemRepo problemRepo;

  public Problem createProblem(Problem problem) {
    return problemRepo.save(problem);
  }

  public List<Problem> getAllProblems() {
    return problemRepo.findAll();
  }

  public Problem getProblemById(Long id) {

        Optional<Problem> problem = problemRepo.findById(id);

        if (problem.isPresent()) {
            return problem.get();
        } else {
            throw new RuntimeException("Problem not found with id: " + id);
        }
    }
}
