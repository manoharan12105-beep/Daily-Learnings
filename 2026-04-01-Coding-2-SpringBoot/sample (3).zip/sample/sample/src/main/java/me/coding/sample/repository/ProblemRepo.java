package me.coding.sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import me.coding.sample.entity.Problem;

public interface ProblemRepo extends JpaRepository <Problem, Long> {
  
}
