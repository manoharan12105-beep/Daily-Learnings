package me.coding.sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import me.coding.sample.entity.User;
import me.coding.sample.service.UserService;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RequestMapping("/api")
@RestController
@CrossOrigin(origins = "*")  
public class UserController {
  
  @Autowired
  private UserService userService;

  @PostMapping("/create")
  public User createUser (@RequestBody User user) {
      
      return userService.createUser(user);
  }

  @PostMapping("/validate")
  public Boolean postMethodName(@RequestBody User user) {
      
      return userService.validate(user);
  }
  
  
}
