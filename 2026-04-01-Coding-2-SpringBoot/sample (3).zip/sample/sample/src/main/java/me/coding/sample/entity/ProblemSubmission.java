package me.coding.sample.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class ProblemSubmission {
  
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long problemSubmissionId;

  @ManyToOne
  @JoinColumn(name = "userId")
  private User user;

  @ManyToOne
  @JoinColumn(name = "problemId")
  private Problem problem;

  @Lob
  @Column(nullable = false, columnDefinition = "LONGTEXT")
  private String code;

  @Column(nullable = false)
  private String status; //Accepted, TLE, WrongSubmit

  @Column(nullable = false)
  private String runtime;
}
