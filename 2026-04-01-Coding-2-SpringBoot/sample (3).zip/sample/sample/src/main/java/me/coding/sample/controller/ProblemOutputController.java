package me.coding.sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import me.coding.sample.entity.ProblemOutput;
import me.coding.sample.service.ProblemOutputService;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") 
public class ProblemOutputController {

  @Autowired
  private ProblemOutputService problemOutputService;

  @PostMapping("/output")
  public ProblemOutput postMethodName(@RequestBody ProblemOutput problemOutput) {
      return problemOutputService.createOutput(problemOutput);
  }
  
  
}
