package me.coding.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import me.coding.sample.entity.ProblemOutput;
import me.coding.sample.repository.ProblemOutputRepo;

@Service
public class ProblemOutputService {

  @Autowired
  private ProblemOutputRepo problemOutputRepo;

  public ProblemOutput createOutput(ProblemOutput problemOutput) {
    return problemOutputRepo.save(problemOutput);
  }  
  
}
