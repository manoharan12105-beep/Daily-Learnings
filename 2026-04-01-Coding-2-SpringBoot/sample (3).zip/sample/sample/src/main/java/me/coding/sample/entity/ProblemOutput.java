package me.coding.sample.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
@Entity
public class ProblemOutput {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne
  @JoinColumn(name = "problemId")
  private Problem problem;

  @Column(nullable = false)
  private String input;

  @Column(nullable = false)
  private String output;

  @Column(nullable = false)
  private String inputType;

  @Column(nullable = false)
  private String outputType;

}
