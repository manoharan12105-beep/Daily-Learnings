package me.coding.sample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import me.coding.sample.entity.Problem;
import me.coding.sample.service.ProblemService;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") 
public class ProblemController {
  @Autowired
  private ProblemService problemService;

  @PostMapping("/add/problem")
  public Problem postMethodName(@RequestBody Problem problem) {
      return problemService.createProblem(problem);
  }

  @GetMapping("/problems")
  public List<Problem> getAllProblems() {
      return problemService.getAllProblems();
  }

  @GetMapping("/problems/{id}")
  public Problem getProblem(@PathVariable long id) {
      return problemService.getProblemById(id);
  }
  
}

// {
//   "title": "GCD of Odd and Even Sums",
//   "level": "Easy",
//   "description": "You are given an integer n. Your task is to compute the GCD (greatest common divisor) of two values:\n\n1. sumOdd: the sum of the first n odd numbers.\n2. sumEven: the sum of the first n even numbers.\n\nReturn the GCD of sumOdd and sumEven.\n\n\nExample 1:\nInput: n = 4\nOutput: 4\nExplanation:\n- Sum of first 4 odd numbers = 1 + 3 + 5 + 7 = 16\n- Sum of first 4 even numbers = 2 + 4 + 6 + 8 = 20\n- GCD(16, 20) = 4\n\nExample 2:\nInput: n = 5\nOutput: 5\nExplanation:\n- Sum of first 5 odd numbers = 1 + 3 + 5 + 7 + 9 = 25\n- Sum of first 5 even numbers = 2 + 4 + 6 + 8 + 10 = 30\n- GCD(25, 30) = 5\n\n\nConstraints:\n1 <= n <= 1000"
// }

/*
Problem List :

  //Easy
    GCD of Odd and Even Sums
    Divisor Game
    Valid Parentheses
    Palindrome Number
    Valid Anagram

  //Medium
    Count and Say
    Longest Substring Without Repeating Characters
    Climbing Stairs

  //Hard
    Longest Valid Parentheses
    Shortest Palindrome

*/
