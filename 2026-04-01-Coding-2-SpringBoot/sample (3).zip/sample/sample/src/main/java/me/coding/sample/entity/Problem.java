package me.coding.sample.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import lombok.Data;

@Data
@Entity
public class Problem {
  
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long problemId;

  @Column(nullable = false)
  private String title;

  @Column(nullable = false)
  private String level;

  @Lob
  @Column(nullable = false, columnDefinition = "LONGTEXT")
  private String description;
}
