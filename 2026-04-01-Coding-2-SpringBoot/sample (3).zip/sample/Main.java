public class Main {
    public static void main(String[] args) {
        int input = Integer.parseInt(args[0]);
        System.out.println(new Solution().solve(input));
    }
}
class Solution {
    public int solve(int input) {
class Solution {

    public int solve(int input) {

        return input;

    }
}
    }
}